.. _api:
  
API documentation
=================

.. toctree::

   autoapi/gefera/index

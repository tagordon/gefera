.. _install:

Installation
=================

*gefera* can be installed using ``pip``:

.. code-block:: bash

   pip install gefera
